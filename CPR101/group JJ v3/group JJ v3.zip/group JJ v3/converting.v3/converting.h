#ifndef CONVERTING_H

#define CONVERTING_H


#include <stdio.h>
#include <string.h>

#include <stdlib.h>

void converting(void);

#endif