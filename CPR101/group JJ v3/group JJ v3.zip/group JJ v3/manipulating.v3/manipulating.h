#ifndef MANIPULATING_H_

#define MANIPULATING H

#include <stdio.h>

#include <string.h>

void manipulating(void);

#endif