
//***************************************************************************** 
// Full Name  : Harshil Prajapati
//student ID#: 175255215
//Email       : hprajapati8@myseneca.ca
//Section    :IPC144ZRA.5605.2227
//Authenticity Declaration:
//I declare this submission is the result of my own work and has not been
//shared with any other student or 3rd party content provider. This submitted
//piece of work is entirely of my own creation
//***************************************************************************** 


void clearInputBuffer(void);


int inputInt();

int inputIntPositive();

int inputIntRange(int lower_limit ,int upper_limit);

char inputCharOption(const char* character);

void inputCString(char* c_string,int min_num, int max_num);

void displayFormattedPhone(const char* phone);